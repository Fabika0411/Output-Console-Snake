#ifndef LIST_H
#define LIST_H

#include "node.h"
#include <cstddef>
#include "memtrace.h"

/**
 * @brief Sablon alapú láncolt lista osztály.
 *
 * Egy egyszerű láncolt lista, amely tetszőleges típusú elemeket tárol.
 * @tparam T A lista által tárolt típus.
 */

template <typename T>
class List {
    Node<T>* head;
public:

    /**
     * @brief Alapértelmezett konstruktor, üres listát hoz létre.
     */

    List() : head() {}

    /**
     * @brief Konstruktor, amely beállítja a lista fejét.
     * @param head_ A lista fejére mutató pointer.
     */

    List(Node<T>* head_) : head(head_) {}

    /**
     * @brief Másoló konstruktor.
     * @param other A másolandó lista.
     */

    List(const List<T>& other);

    /**
     * @brief Destruktor, felszabadítja a lista elemeit.
     */

    ~List() { clear(); }

    /**
     * @brief Hozzáad egy új elemet a lista elejére.
     * @param data Az új elem adata.
     */

    void add(T data);

    /**
     * @brief Eltávolítja a lista utolsó elemét.
     */

    void remove_back();

    /**
     * @brief Törli az összes elemet a listából.
     */

    void clear();

    /**
    * @brief Visszaadja a lista fejét.
    * @return A fejre mutató pointer.
    */

    Node<T>* get_head() { return head; }

    /**
    * @brief Visszaadja a lista fejét.
    * @return A fejre mutató pointer.
    */

    void set_head(Node<T>* head_) { head = head_; }

    /**
     * @brief Másoló értékadó operátor.
     * @param rhs A másolandó lista.
     * @return Referencia az aktuális listára.
     */

    List<T>& operator=(const List<T>& rhs);

    /**
     * @brief Visszaadja a lista méretét.
     * @return Az elemek száma.
     */

    int size() const; // Visszaadja a lista méretét
};

/// --- Metódusok implementációja ---

template <typename T>
void List<T>::add(T data) {
    Node<T>* old_head=head;
    head = new Node<T>(data);
    head->next = old_head;
}

template <typename T>
void List<T>::clear() {
    while (head != nullptr) {
        Node<T>* temp = head;
        head = head->next;
        delete temp;
    }
}

template<typename T>
int List<T>::size() const {
    int count = 0;
    Node<T>* current = head;
    while (current) {
        ++count;
        current = current->next;
    }
    return count;
}

template <typename T>
void List<T>::remove_back() {
    if (!head) {
        // Lista üres, nincs mit törölni
        return;
    }
    if (!head->next) {
        // Csak egy elem van a listában
        delete head;
        head = nullptr;
        return;
    }
    Node<T>* current = head;
    while (current->next->next != nullptr) {
        current=current->next;
    }
    delete current->next;
    current->next=nullptr;
}

template <typename T>
List<T>& List<T>::operator=(const List<T>& rhs) {
    if (this != &rhs) {
        clear();
        Node<T>* current = rhs.head;
        Node<T>* last = nullptr;
        while (current) {
            Node<T>* newNode = new Node<T>(current->data);
            if (!head) {
                head = newNode;
            } else {
                last->next = newNode;
            }
            last = newNode;
            current = current->next;
        }
    }
    return *this;
}

template <typename T>
List<T>::List(const List<T>& other) : head(nullptr) {
    Node<T>* current = other.head;
    Node<T>* last = nullptr;
    while (current) {
        Node<T>* newNode = new Node<T>(current->data);
        if (!head) {
            head = newNode;
        } else {
            last->next = newNode;
        }
        last = newNode;
        current = current->next;
    }
}
#endif //LIST_H
