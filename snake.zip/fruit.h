#ifndef FRUIT_H
#define FRUIT_H

#include "point.h"
#include "list.h"

class Snake;

/**
 *
 * A gyümölcsöt reprezentáló absztrakt osztály, amely tartalmazza a pozíciót és a típust.
 */

class Fruit {
protected:

    /**
     * A gyümölcs pozíciója.
     */

    Point pos; //a gyümölcs pozíciója

    /**
     * A gyümölcs típusa.
     */

    int type;
public:

    /**
     *
     * Visszaadja a gyümölcs pozícióját.
     * @return A gyümölcs pozíciója (Point referencia).
     */

    Point& get_pos() { return pos; }

    /**
     *
     * Visszaadja a gyümölcs típusát.
     * @return A gyümölcs típusa (int).
     */

    int get_type() { return type; }

    /**
     *
     * Beállítja a gyümölcs típusát.
     * @param type_of_fruit Az új gyümölcs típus (int).
     */

    void set_type(int type_of_fruit) { type = type_of_fruit; }
    /**
     *
     * Beállítja a gyümölcs pozícióját.
     * @param x Az új x koordináta.
     * @param y Az új y koordináta.
     */
    void set_pos(int x, int y) { pos.set_x(x); pos.set_y(y); }

 /**
  *
  * Absztrakt metódus, amely meghatározza a gyümölcs hatását a kígyóra.
  * @param snake A kígyó objektum referenciája.
  * @param x A pálya szélessége.
  * @param y A pálya magassága.
  */

    virtual void affect(Snake& snake, int x, int y) = 0; //a gyümölcs hatása a kígyóra
 /**
  *
  * A Fruit osztály virtuális destruktora.
  */
    virtual ~Fruit() = default;
};
#endif //FRUIT_H
