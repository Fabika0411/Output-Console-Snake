#ifndef WHITE_H
#define WHITE_H

#include "fruit.h"
#include "field.h"

/**
 * @brief A fehér gyümölcsöt reprezentáló osztály, amely a Fruit osztályból származik.
 */

class White : public Fruit {
protected:
    int calorie; /**< A gyümölcs által adott kalória (kígyó méretnövelés). */
public:

    /**
     * @brief Alapértelmezett konstruktor, beállítja a kalóriát 10-re.
     */

    White() : calorie(10) {}

    /**
     * @brief A fehér gyümölcs hatása a kígyóra: növeli a méretét és visszaállítja a sebességet.
     * @param kigyo A kígyó objektum referenciája.
     * @param szelesseg A pálya szélessége.
     * @param magassag A pálya magassága.
     */

    void affect(Snake& kigyo, int szelesseg, int magassag) override; //a fehér gyümölcs hatása a kígyóra
};
#endif //WHITE_H
