#ifndef FIELD_H
#define FIELD_H

#include "point.h"
#include "fruit.h"

class Snake;

class Field {
protected:
    /**
     * A pálya szélessége és magassága, valamint a fal pozíciója.
     */
    int width, height;
    /**
     * A fal pozíciója, amely egy Point objektum.
     */
    Point wall;
public:
    /**
     *
     * Alapértelmezett konstruktor, amely beállítja a pálya szélességét és magasságát 0-ra, valamint a fal pozícióját.
     */
    Field() : width(0), height(0), wall() {}
    /**
     *
     * Konstruktor, amely beállítja a pálya szélességét, magasságát és a fal pozícióját.
     * @param width_of_field A pálya szélessége.
     * @param height_of_field A pálya magassága.
     * @param wall A fal pozíciója.
     */
    Field(int width_of_field, int height_of_field, Point& wall)
        : width(width_of_field), height(height_of_field), wall(wall) {}
    /**
     *
     * Visszaadja a pálya szélességét.
     * @return A pálya szélessége.
     */
    int get_width() const { return width; }
    /**
     *
     * Visszaadja a pálya magasságát.
     * @return A pálya magassága.
     */
    int get_height() const { return height; }
    /**
     *
     * Beállítja a pálya szélességét.
     * @param width_of_field Az új szélesség.
     */
    void set_width(int width_of_field) { width = width_of_field; }

    /**
     *
     * Beállítja a pálya magasságát.
     * @param height_of_field Az új magasság.
     */

    void set_height(int height_of_field) { height = height_of_field; }

    /**
     *
     * Visszaadja a fal pozícióját.
     * @return A fal pozíciója.
     */

    Point& get_wall() { return wall; }

    /**
    *
    * Véletlenszerűen generál egy falat a pályán.
    * @param fruit A gyümölcs objektumra mutató pointer.
    */

    void wall_generate(Fruit*& fruit);

    /**
     *
     * Véletlenszerűen generál egy gyümölcsöt a pályán.
     * @param snake_data A kígyó objektum referenciája.
     * @param fruit A gyümölcs objektumra mutató pointer.
     * @param random_number Meghatározza a gyümölcs típusát/színét.
     */

    void fruit_generate(Snake& snake_data, Fruit*& fruit, int random_number);

    /**
     *
     * A kígyót a pálya közepére helyezi és inicializálja a testét.
     * @param snake A kígyó objektum referenciája.
     */

    void snake_generate(Snake& snake) const;

    /**
     *
     * A Field osztály destruktora.
     */

    ~Field()= default;
};
#endif //FIELD_H
