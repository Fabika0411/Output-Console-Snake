#include <iostream>
#include "ctime"
#include "snake.h"
#include "econio.h"
#include "point.h"
#include "field.h"
#include "cstddef"
#include "fruit.h"
#include "white.h"
#include "green.h"
#include "purple.h"
#include "memtrace.h"


using namespace std;

/**
 * @brief A kígyó mozgási irányát bekérő függvény.
 * @return A lenyomott irány billentyű kódja.
 */

int Snake::direction() {
    econio_rawmode();
    while(direction_of_movement!=KEY_UP && direction_of_movement!=KEY_DOWN && direction_of_movement!=KEY_LEFT && direction_of_movement!=KEY_RIGHT) {
        direction_of_movement=econio_getch();
        if(direction_of_movement==KEY_UP) {
            return KEY_UP;
        }
        if(direction_of_movement==KEY_DOWN){;
            return KEY_DOWN;
        }
        if(direction_of_movement==KEY_LEFT){
            return KEY_LEFT;
        }
        if(direction_of_movement==KEY_RIGHT){
            return KEY_RIGHT;
        }
    }
    return 0;
}

/**
 * @brief A kígyó mozgatását, ütközését, gyümölcsevést és kirajzolását vezérlő fő ciklus.
 * @param field_data A pálya adatai.
 * @param fruit_data A gyümölcsre mutató pointer.
 */

void Snake::move(Field& field_data, Fruit*& fruit_data) {
    direction(); // kezdőirány
    int win_condition = 10*size;

    while (true) {
        print_score(field_data.get_width());
        if(score == win_condition) {
            break;
        }

        // --- Kezeljük az új irányt ---
        if (econio_kbhit()) {
            int key = econio_getch();
            if (key == KEY_UP && direction_of_movement != KEY_DOWN) direction_of_movement = KEY_UP;
            else if (key == KEY_DOWN && direction_of_movement != KEY_UP) direction_of_movement = KEY_DOWN;
            else if (key == KEY_LEFT && direction_of_movement != KEY_RIGHT) direction_of_movement = KEY_LEFT;
            else if (key == KEY_RIGHT && direction_of_movement != KEY_LEFT) direction_of_movement = KEY_RIGHT;
            else if (key == KEY_BACKSPACE) {
                direction_of_movement = KEY_BACKSPACE;
                break;
            }
        }

        // --- Új fejpozíció kiszámítása ---
        Point new_head = head;
        if (direction_of_movement == KEY_UP) new_head.set_y(head.get_y() - 1);
        if (direction_of_movement == KEY_DOWN) new_head.set_y(head.get_y() + 1);
        if (direction_of_movement == KEY_LEFT) new_head.set_x(head.get_x() - 1);
        if (direction_of_movement == KEY_RIGHT) new_head.set_x(head.get_x() + 1);

        // --- Kirajzolás új fej ---
        print(head.get_x(), head.get_y(), 0);
        print(new_head.get_x(), new_head.get_y(), 1); // fej piros 'O'

        // --- Test frissítése ---
        body.add(head); // előző fej most már test
        // Töröld a legrégebbi pontot (lista elejéről)
        if(body.size() > size) {
            print(get_tail().get_x(), get_tail().get_y(), -1); // töröld képernyőről
            body.remove_back();
        }
        head = new_head; // frissítsd a fejet
        // --- Ütközés ellenőrzés ---
        if(crash(field_data)==true) {
            cout<<"Ütközés történt, vesztett!"<<endl;
            break;
        }
        // --- Ellenőrizd, hogy a kígyó megeszi-e a gyümölcsöt ---
        int random_number=rand() % 3;
        if (eat(fruit_data->get_pos())==true && score<win_condition) {
            score++;
            //fruit_data->set_pos(0, 0);
            fruit_data->affect(*this, field_data.get_width(), field_data.get_height());
            delete fruit_data;
            if ( random_number == 0 )
                fruit_data = new White(); // új gyümölcs létrehozása
            else if ( random_number == 1 )
                fruit_data = new Green();
            else if ( random_number == 2 )
                fruit_data  = new Purple();
            fruit_data->set_pos(0,0);
            field_data.fruit_generate(*this, fruit_data, random_number); // új gyümölcs generálása
        }else if ( random_number == 0 && fruit_data->get_type()==0) {
            econio_gotoxy(fruit_data->get_pos().get_x(), fruit_data->get_pos().get_y());
            econio_textcolor(COL_WHITE);
            cout << "G";
            econio_textcolor(COL_RESET);
        }else if ( random_number == 1 && fruit_data->get_type()==1) {
            econio_gotoxy(fruit_data->get_pos().get_x(), fruit_data->get_pos().get_y());
            econio_textcolor(COL_GREEN);
            cout << "G";
            econio_textcolor(COL_RESET);
        }else if ( random_number == 2 && fruit_data->get_type() == 2 ) {
            econio_gotoxy(fruit_data->get_pos().get_x(), fruit_data->get_pos().get_y());
            econio_textcolor(COL_MAGENTA);
            cout << "G";
            econio_textcolor(COL_RESET);
        }
        // --- Késleltetés ---
        econio_sleep(speed);
    }

    econio_normalmode();
}

/**
 * @brief Növeli a kígyó méretét.
 * @param calories A növelés mértéke.
 */

void Snake::size_inc(int calories) {
    size+=calories;
}

/**
 * @brief A kígyó teleportálása a pálya egy másik negyedébe.
 * @param szelesseg A pálya szélessége.
 * @param magassag A pálya magassága.
 * @param fruit_position A gyümölcs pozíciója.
 */

void Snake::teleport(int szelesseg, int magassag, Point& fruit_position) {
    srand(time(nullptr));
    int origo_1=szelesseg/2;
    int origo_2=magassag/2;
    int x;
    int y;
    Node<Point>* current = body.get_head();
    while (current->next != nullptr) {
        if(head.get_x()>origo_1 && head.get_y()>origo_2) {
            do {
                x = rand()% (szelesseg-3) + 3;
                y = rand()% (magassag-3) + 3;
            }while((x>origo_1 && y>origo_2) || (fruit_position.get_x()==x && fruit_position.get_y()==y) || (x == head.get_x() && y == head.get_y()) || (x == current->data.get_x() && y == current->data.get_y()));
            print(head.get_x(), head.get_y(), -1);
            head.set_x(x);
            head.set_y(y);
            print(x, y, 0);
        }else if(head.get_x()>origo_1 && head.get_y()<origo_2) {
            do {
                x = rand()% (szelesseg-3) + 3;
                y = rand()% (magassag-3) + 3;
            }while((x>origo_1 && y<origo_2) || (fruit_position.get_x()==x && fruit_position.get_y()==y) || (x == head.get_x() && y == head.get_y()) || (x == current->data.get_x() && y == current->data.get_y()));
            print(head.get_x(), head.get_y(), -1);
            head.set_x(x);
            head.set_y(y);
            print(x, y, 0);
        }else if(head.get_x()<origo_1 && head.get_y()>origo_2) {
            do {
                x = rand()% (szelesseg-3) + 3;
                y = rand()% (magassag-3) + 3;
            }while((x<origo_1 && y>origo_2) || (fruit_position.get_x()==x && fruit_position.get_y()==y) || (x == head.get_x() && y ==head.get_y()) || (x == current->data.get_x() && y == current->data.get_y()));
            print(head.get_x(), head.get_y(), -1);
            head.set_x(x);
            head.set_y(y);
            print(x, y, 0);
        }else if(head.get_x()<origo_1 && head.get_y()<origo_2) {
            do {
                x = rand()% (szelesseg-3) + 3;
                y = rand()% (magassag-3) + 3;
            }while((x<origo_1 && y<origo_2) || (fruit_position.get_x()==x && fruit_position.get_y()==y) || (x == head.get_x() && y == head.get_y()) || (x == current->data.get_x() && y == current->data.get_y()));
            print(head.get_x(), head.get_y(), -1);
            head.set_x(x);
            head.set_y(y);
            print(x, y, 0);
        }else if(head.get_x()==origo_1 && head.get_y()==origo_2) {
            do {
                x = rand()% (szelesseg-3) + 3;
                y = rand()% (magassag-3) + 3;
            }while((x==origo_1 && y==origo_2) || (fruit_position.get_x()==x && fruit_position.get_y()==y) || (x == head.get_x() && y == head.get_y()) || (x == current->data.get_x() && y == current->data.get_y()));
            print(head.get_x(), head.get_y(), -1);
            head.set_x(x);
            head.set_y(y);
            print(x, y, 0);
        }
        current = current->next;
    }
}

/**
 * @brief Felgyorsítja a kígyót.
 */

void Snake::speed_up() {
    set_speed(speed/2);
    econio_sleep(speed);
}

/**
 * @brief Kirajzolja a kígyó fejét vagy testét a pályára, vagy törli azt.
 * @param x Az x koordináta.
 * @param y Az y koordináta.
 * @param body_type 0: fej, 1: test, -1: törlés.
 */

void Snake::print(int x, int y, int body_type) {
    econio_gotoxy(x, y);
    if(body_type==0) {
        econio_textcolor(COL_RED);
        cout<<"0";
    }
    if(body_type==1){
        econio_textcolor(COL_RED);
        cout<<">";
    }
    if(body_type==-1) {
        cout<<" ";
    }
    econio_textcolor(COL_RESET);
}

/**
 * @brief Ellenőrzi, hogy a kígyó ütközött-e a falnak vagy saját magának.
 * @param field_data A pálya adatai.
 * @return Igaz, ha ütközés történt.
 */

bool Snake::crash(Field& field_data) {
    Node<Point>* current = body.get_head();
    while (current->next != nullptr) {
        current = current->next;
        if(head.get_x()<=0 || head.get_x()>=field_data.get_width() || head.get_y()<=0 || head.get_y()>=field_data.get_height() || (head.get_x() == field_data.get_wall().get_x() && head.get_y() == field_data.get_wall().get_y()) || (head.get_x() == current->data.get_x() && head.get_y() == current->data.get_y())) {
            return true;
        }
    }
    return false;
}

/**
 * @brief Ellenőrzi, hogy a kígyó megeszi-e a gyümölcsöt.
 * @param point A gyümölcs pozíciója.
 * @return Igaz, ha a kígyó feje a gyümölcs pozícióján van.
 */

bool Snake::eat(const Point& point) {
        if (head.get_x() == point.get_x() && head.get_y() == point.get_y()) {
            return true;
        }
        return false;
}

/**
 * @brief Visszaadja a kígyó farkának pozícióját.
 * @return A farok pozíciója (Point).
 */

Point Snake::get_tail() {
    Node<Point>* current = body.get_head();
    while (current->next != nullptr) {
        current=current->next;
    }
    return current->data;
}

/**
 * @brief Kiírja a pontszámot a pálya tetejére.
 * @param x A pálya szélessége (x koordináta).
 */

void Snake::print_score(int x) const {
    econio_gotoxy(x, 0);
    cout<<"Score: "<<score;

}

/**
 * @brief A Snake osztály destruktora, felszabadítja a testet.
 */

Snake::~Snake() {
    body.clear();
    size=4;
}