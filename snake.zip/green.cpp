#include "snake.h"
#include "green.h"
#include "field.h"
#include "point.h"
#include "list.h"
#include "memtrace.h"

/**
 *
 * A Green osztály affect metódusa, amely teleportálja a kígyót a gyümölcs pozíciójára,
 * és beállítja a kígyó sebességét, ha a gyümölcs típusa zöld.
 * @param kigyo A kígyó objektum referenciája.
 * @param szelesseg A pálya szélessége.
 * @param magassag A pálya magassága.
 */

void Green::affect(Snake& kigyo, int szelesseg, int magassag) {
        if(get_type()==1) {
            kigyo.teleport(szelesseg, magassag, get_pos());
            if ( kigyo.get_speed() != 0.145)
                kigyo.set_speed(0.145);
        }
}
