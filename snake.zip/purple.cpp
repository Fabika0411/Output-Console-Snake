#include "snake.h"
#include "field.h"
#include "purple.h"
#include "memtrace.h"

/**
 * @brief A Purple osztály affect metódusa.
 *
 * Ha a gyümölcs típusa lila (2), akkor felgyorsítja a kígyót.
 * @param kigyo A kígyó objektum referenciája.
 * @param szelesseg A pálya szélessége.
 * @param magassag A pálya magassága.
 */

void Purple::affect(Snake& kigyo, int szelesseg, int magassag) {
    if(get_type() == 2)
        kigyo.speed_up();
}