#include "white.h"
#include "list.h"
#include "field.h"
#include "snake.h"
#include "point.h"
#include "game.h"
#include "memtrace.h"

/**
 * @brief A White osztály affect metódusa.
 *
 * Ha a gyümölcs típusa fehér (0), akkor megnöveli a kígyó méretét, hozzáad egy új test elemet a megfelelő irányban,
 * és visszaállítja a kígyó sebességét az alapértelmezettre, ha szükséges.
 * @param kigyo A kígyó objektum referenciája.
 * @param szelesseg A pálya szélessége.
 * @param magassag A pálya magassága.
 */

void White::affect(Snake& kigyo, int szelesseg, int magassag) {
    if(get_type()==0) {
        kigyo.size_inc(calorie);

        // Kígyó testének utolsó elemének meghatározása
        Point last_point = kigyo.get_tail();

        // Új test elem pozíciója az irány alapján
        int dir = kigyo.get_direction(); // feltételezve, hogy tárolt irányt ad vissza
        if (dir == -20) { // fel
            last_point.set_y(last_point.get_y() - 1);
        } else if (dir == -21) { // le
            last_point.set_y(last_point.get_y() + 1);
        } else if (dir == -22) { // balra
            last_point.set_x(last_point.get_x() - 1);
        } else if (dir == -23) { // jobbra
            last_point.set_x(last_point.get_x() + 1);
        }
        kigyo.get_body().add(last_point);
        if ( kigyo.get_speed() != 0.145)
            kigyo.set_speed(0.145);
    }
}
