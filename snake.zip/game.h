#ifndef GAME_H
#define GAME_H

#include <iostream>
#include "snake.h"
#include "field.h"
#include "fruit.h"
#include "econio.h"

class Game {
protected:
 Field field;           /**< A pálya objektum. */
 Snake snake;           /**< A kígyó objektum. */
 Fruit* fruit = nullptr;/**< A gyümölcs objektumra mutató pointer. */
 bool end_game,         /**< Jelzi, hogy vége van-e a játéknak. */
      loaded_game;      /**< Jelzi, hogy betöltött játék-e. */
public:

    /**
     *
     * Alapértelmezett konstruktor, amely inicializálja a játék állapotát.
     */

    Game() : end_game(false), loaded_game(false) {}

 /**
  *
  * Beállítja a játék végének állapotát.
  * @param end_game_data Igaz, ha a játék véget ért, egyébként hamis.
  */

    void set_end_game(bool end_game_data){ end_game=end_game_data; }

 /**
   *
   * Beállítja, hogy a játék betöltött állapotban van-e.
   * @param loaded_game_data Igaz, ha betöltött játék, egyébként hamis.
   */
    void set_loaded_game(bool loaded_game_data){ loaded_game=loaded_game_data; }

 /**
  *
  * A játék fő ciklusa, amely elindítja és vezérli a játék menetét.
  */
    void game_loop();

    /**
     *
     * A Game osztály metódusa, amely elvégzi a játék tesztelését.
     */

    void test(); //tesztelés
    /**
     *
     * A Game osztály metódusa, amely elmenti a játék aktuális állapotát egy fájlba.
     */
    void save(); //a játék mentése
    /**
     *
     * A Game osztály metódusa, amely betölti a játék állapotát egy fájlból.
     */
    void load(); //a játék betöltése
    /**
     *
     * A Game osztály metódusa, amely kirajzolja a pálya szélét a képernyőre.
     */
    void print_field(); //kiírja a pontszámot a képernyőre

    /**
     *
     * A Game osztály destruktora, amely felszabadítja a kígyó testét.
     */

    ~Game();
};

#endif //GAME_H
