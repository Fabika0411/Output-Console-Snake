#ifndef GREEN_H
#define GREEN_H

#include "fruit.h"
#include "snake.h"
#include "field.h"

/**
 *
 * A zöld gyümölcsöt reprezentáló osztály, amely a Fruit osztályból származik.
 */

class Green : public Fruit {
public:

    /**
     *
     * Alapértelmezett konstruktor, amely inicializálja a zöld gyümölcsöt.
     */

    Green() : Fruit() {} //default konstruktor

    /**
     *
     * A zöld gyümölcs hatása a kígyóra: teleportálja a kígyót a gyümölcs pozíciójára és módosítja a sebességét.
     * @param kigyo A kígyó objektum referenciája.
     * @param szelesseg A pálya szélessége.
     * @param magassag A pálya magassága.
     */

    void affect(Snake& kigyo, int szelesseg, int magassag) override; //a zöld gyümölcs hatása a kígyóra
};

#endif //GREEN_H
