#include <iostream>
#include "game.h"
#include "field.h"
#include "snake.h"
#include "fruit.h"
#include "purple.h"
#include "white.h"
#include "list.h"
#include "memtrace.h"

/// 0: teszt
/// 1: játék

#define RUN 1

#if RUN == 0

/**
 * @brief A teszteseteket végző fő függvény. RUN egyenlő 0 esetén fut le.
 */

int main() {
    Game game;
    game.test();
}
#endif

#if RUN == 1

/**0 0
 * @brief Magát a játékot futtató fő függvény. RUN egyenlő 1 esetén fut le.
 */

int main() {
    Game game;
    game.game_loop();
    return 0;
}
#endif
