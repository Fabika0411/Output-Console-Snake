#include <iostream>
#include "game.h"
#include "white.h"
#include "green.h"
#include "purple.h"
#include "gtest_lite.h"
#include <fstream>
#include <string>
#include "memtrace.h"

using namespace std;

/**

A Game osztály metódusa, amely kirajzolja a pálya szélét a képernyőre. */

void Game::print_field() {
    for(int i=0; i<field.get_height(); i++) {
        econio_gotoxy(0, i);
        cout<<"H";
        econio_gotoxy(field.get_width(), i);
        cout<<"H";
    }
    for(int i=0; i<field.get_width()+1; i++) {
        econio_gotoxy(i, 0);
        cout<<"_";
        econio_gotoxy(i, field.get_height());
        cout<<"T";
    }
}

/**

Elmenti a játék aktuális állapotát egy fájlba. */

void Game::save() {
    ofstream file_out("save.txt");

    if ( !file_out ) {
        cerr << "Hiba a fájl megnyitásakor!" << endl;

    }else if ( file_out.is_open() ){
        Node<Point>* current = snake.get_body().get_head();
        file_out << snake.get_score() << endl;
        file_out << snake.get_size() << endl;
        file_out << snake.get_head().get_x() << "," << snake.get_head().get_y() << endl;
        while ( current->next != nullptr ) {
            current = current->next;
            file_out << current->data.get_x() << "," << current->data.get_y() << ";";
        }
        file_out << snake.get_speed() << endl;
        file_out<< endl;
        file_out << field.get_width() << field.get_height() << endl;
        file_out << field.get_wall().get_x() << "," << field.get_wall().get_y() << endl;
        file_out << fruit->get_pos().get_x() << "," << fruit->get_pos().get_y() << endl;
        file_out << fruit->get_type() << endl;
        file_out.close();
    }
}

/**

Betölti a játék állapotát egy fájlból. */

void Game::load() {
    ifstream file_in("save.txt");
    if ( !file_in ) {
        cerr << "Hiba a fájl megnyitásakor!" << endl;
        return;
    }
    string line;
    getline(file_in, line);
    snake.set_score(stoi(line));
    getline(file_in, line);
    snake.set_size(stoi(line));
    getline(file_in, line);
    int x, y;
    sscanf(line.c_str(), "%d,%d", &x, &y);
    snake.get_head().set_x(x);
    snake.get_head().set_y(y);

    getline(file_in, line);
    snake.get_body().clear();
    size_t pos = 0;
    while ((pos = line.find(";")) != string::npos) {
        string token = line.substr(0, pos);
        sscanf(token.c_str(), "%d,%d", &x, &y);
        snake.get_body().add(Point(x, y));
        line.erase(0, pos + 1);
    }

    getline(file_in, line);
    snake.set_speed(stod(line));

    getline(file_in, line);
    sscanf(line.c_str(), "%d%d", &x, &y);
    field.set_width(x);
    field.set_height(y);

    getline(file_in, line);
    sscanf(line.c_str(), "%d,%d", &x, &y);
    field.get_wall().set_x(x);
    field.get_wall().set_y(y);

    getline(file_in, line);
    sscanf(line.c_str(), "%d,%d", &x, &y);
    fruit->set_pos(x, y);

    getline(file_in, line);
    fruit->set_type(stoi(line));

    file_in.close();
}

/**

A játék fő ciklusa, amely kezeli a pálya beállítását, a játék menetét és a győzelmi feltételeket. */

void Game::game_loop() {
    /*bool quit_game = false;
    while ( quit_game != true ) {
        econio_rawmode();
        cout << "A jatek elinditasahoz nyomja meg az ENTER-t, vagy a mentett jatek betolteshez nyomja meg a tabulator billentyut. Ha ki szeretne lepni, nyomja meg a BACKSPACE billentyut." << endl;

        int game_key = econio_getch();

        econio_normalmode();
        econio_clrscr();
        if ( game_key == KEY_ENTER) {*/
    bool quit_game = false;

    int key;

    while (!quit_game){
        end_game=false;
        snake.set_size(5);
        snake.set_direction(0);
        snake.set_score(0);
        snake.set_speed(0.145);

        while (true) {
            econio_gotoxy(63,10);

            econio_textcolor(COL_LIGHTRED);

            cout << "FELFELE NYÍL: START" << endl;

            econio_gotoxy(63, 15);

            cout << "LEFELE NYÍL: QUIT" << endl;

            econio_textcolor(COL_RESET);

            econio_rawmode();

            key=econio_getch();

            econio_normalmode();

            if(!(key == KEY_UP || key == KEY_DOWN)) {
                econio_gotoxy(63,  25);
                cout << "Hibás billentyű!";
            }else {
                break;
            }
        }

        if(key == KEY_UP){

            econio_clrscr();

            econio_gotoxy(0, 10);

            econio_textcolor(COL_LIGHTRED);

            cout<<"Adja meg a pálya méretét (szélesség, magasság). Egyik szám, majd szóköz, másik szám, enter."
    "Ha nem szeretne beállítani semmit, akkor vigye be a 0-át, egyéb esetben adjon meg egy minimum 50x10 maximum 100x25 méretű pályát."<<endl
    <<"Ide írja a választásait: ";

            econio_textcolor(COL_RESET);

            int x, y;

            while (true) {

                if (!(cin >> x >> y)) {
                    if (cin.eof()) {
                        cerr << "\nBeolvasas megszakadt (EOF)!" << endl;
                        exit(1); // vagy break / return
                    }
                    cerr << "Hibas input! Csak szamokat adjon meg." << endl;
                    cin.clear(); // hibaflag törlés
                    cin.ignore(numeric_limits<streamsize>::max(), '\n'); // rossz sor kidobása
                    continue;
                }

                // Elfogadható értékek: vagy 0 0, vagy az érvényes tartományban van
                if ((x == 0 && y == 0) || (x >= 50 && x <= 100 && y >= 10 && y <= 25)) {
                    cout << "A jatek megkezdodott!" << endl;
                    break;
                } else {
                    cerr << "Hibas meretek! x ∈ [50,100], y ∈ [10,25], vagy 0 0." << endl;
                }

            } //így biztosan látszódni fog a pálya
            econio_clrscr();
            if(x==0 && y==0) {
                field.set_width(100);
                field.set_height(25);
            }else {
                field.set_width(x);
                field.set_height(y);
            }
            field.snake_generate( snake );

            int random_color = rand() % 3;
            if ( random_color == 0 ) {
                fruit = new White();
            }else if ( random_color == 1 ) {
                fruit = new Green();
            }else if ( random_color == 2 ) {
                fruit = new Purple();
            }
            field.fruit_generate(snake, fruit, random_color);
            /*}else if ( game_key == KEY_TAB ) {
                load();
                econio_gotoxy(field.get_width(), field.get_height());
                econio_textcolor(COL_CYAN);
                cout << "A jatek betoltve!" << endl;
                econio_textcolor(COL_RESET);
                econio_clrscr();
                field.snake_generate(snake);
            }else if ( game_key == KEY_BACKSPACE) {
                quit_game = true;
                econio_clrscr();
                econio_gotoxy(field.get_width()/2, field.get_height()/2);
                econio_textcolor(COL_RED);
                cout << "A jatek bezarva!" << endl;
                econio_textcolor(COL_RESET);
            }*/

            int size = snake.get_size();
            int win_condition = 10*size;

            while(!end_game) {
                print_field();
                field.wall_generate(fruit);
                snake.move(field, fruit);
                end_game=snake.crash(field);
                if ( snake.get_direction() == KEY_BACKSPACE) {
                    econio_rawmode();
                    int key = econio_getch();
                    econio_normalmode();
                    if (key == KEY_ENTER) {
                        save();
                        econio_gotoxy(field.get_width()/2, field.get_height()/2);
                        econio_textcolor(COL_CYAN);
                        cout << "A jatek elmentve!" << endl;
                        econio_textcolor(COL_RESET);
                        econio_clrscr();
                        end_game = true;
                    }else if (key == KEY_BACKSPACE) {
                        econio_clrscr();
                        end_game = true;
                    }
                }
                if (snake.get_score() == win_condition) {
                    end_game = true;
                    econio_gotoxy(snake.get_head().get_x(), snake.get_head().get_y());
                    econio_textcolor(COL_YELLOW);
                    cout << "Gratulálunk, nyertél!" << endl;
                }

            }

            if(snake.crash(field)) {
                econio_gotoxy(field.get_wall().get_x()+1, field.get_wall().get_y());

                econio_textcolor(COL_LIGHTRED);

                cout << "Nyomj bármilyen billentyűt a tovább lépéshez!" << endl;

                econio_textcolor(COL_RESET);

                econio_rawmode();

                econio_getch();

                econio_normalmode();
            }

            delete fruit;
            snake.get_body().clear();

            econio_clrscr();

        }else{
            quit_game=true;
        }
    }
}
//}


/**

Teszteseteket futtat a program főbb osztályaira és metódusaira. */

void Game::test() {

    TEST (Test1, Field) {

        Point p(1, 1);
        Field field ( 50, 50, p);
        EXPECT_EQ(50, field.get_width());
        EXPECT_EQ(50, field.get_height());
        EXPECT_EQ(1, field.get_wall().get_x());
        EXPECT_EQ(1, field.get_wall().get_y());

        field.set_width(100);
        field.set_height(100);
        EXPECT_EQ(100, field.get_width());
        EXPECT_EQ(100, field.get_height());

        fruit = new White();
        field.snake_generate(snake);
        field.fruit_generate(snake, fruit, 0);
        field.wall_generate(fruit);
        snake.get_body().clear();
        delete fruit;

    } ENDM

    TEST (Test2, Fruit) {

        fruit = new White();
        fruit->set_pos(1, 1);
        fruit->set_type(0);
        EXPECT_EQ(1, fruit->get_pos().get_x());
        EXPECT_EQ(1, fruit->get_pos().get_y());
        EXPECT_EQ(0, fruit->get_type());

        Point p1(2,2);
        Point p2(2,3);
        snake.get_body().add(p1);
        snake.get_body().add(p2);
        snake.get_head().set_x(1);
        snake.get_head().set_y(1);
        EXPECT_TRUE(snake.eat(fruit->get_pos()));

        fruit->affect(snake, field.get_width(), field.get_height());
        EXPECT_FALSE(5 == snake.get_size());
        snake.get_body().clear();
        delete fruit;

        fruit = new Green();
        fruit->set_pos(1, 1);
        fruit->set_type(1);
        EXPECT_EQ(1, fruit->get_pos().get_x());
        EXPECT_EQ(1, fruit->get_pos().get_y());
        EXPECT_EQ(1, fruit->get_type());

        EXPECT_TRUE(snake.eat(fruit->get_pos()));
        delete fruit;

        fruit = new Purple();
        fruit->set_pos(1, 1);
        fruit->set_type(2);
        EXPECT_EQ(1, fruit->get_pos().get_x());
        EXPECT_EQ(1, fruit->get_pos().get_y());
        EXPECT_EQ(2, fruit->get_type());

        snake.get_head().set_x(1);
        snake.get_head().set_y(1);
        EXPECT_TRUE(snake.eat(fruit->get_pos()));

        fruit->affect(snake, field.get_width(), field.get_height());
        EXPECT_EQ(0.0725, snake.get_speed());
        delete fruit;

    } ENDM

    TEST (Test3, Game) {

        set_end_game(true);
        EXPECT_TRUE(end_game);

        set_end_game(false);
        EXPECT_FALSE(end_game);

        set_loaded_game(true);
        EXPECT_TRUE(loaded_game);

        set_loaded_game(false);
        EXPECT_FALSE(loaded_game);

    }ENDM

    TEST (Test4, List) {
        List<Point> list;
        Point p1(1, 1);
        Point p2(2, 2);
        Point p3(3, 3);

        list.add(p1);
        list.add(p2);
        list.add(p3);
        EXPECT_EQ(3, list.size());

        Node<Point>* head = list.get_head();
        EXPECT_EQ(3, head->data.get_x());
        EXPECT_EQ(3, head->data.get_y());

        head = head->next;
        EXPECT_EQ(2, head->data.get_x());
        EXPECT_EQ(2, head->data.get_y());

        head = head->next;
        EXPECT_EQ(1, head->data.get_x());
        EXPECT_EQ(1, head->data.get_y());

        head = list.get_head();
        list.remove_back();
        EXPECT_EQ(3, head->data.get_x());
        EXPECT_EQ(3, head->data.get_y());
        EXPECT_EQ(2, list.size());

        List<Point> new_list;

        Point point_new(4, 4);

        new_list.add(point_new);
        list = new_list;
        EXPECT_EQ(1, list.size());
        EXPECT_EQ(4, list.get_head()->data.get_x());
        EXPECT_EQ(4, list.get_head()->data.get_y());

        list.clear();
        EXPECT_EQ(0, list.size());

    }ENDM

    TEST(Test5, Point) {

        Point p(1,1); //pont létrehozása
        EXPECT_EQ(1, p.get_x());
        EXPECT_EQ(1, p.get_y());

        p.set_x(2);
        p.set_y(3);
        EXPECT_EQ(2, p.get_x());
        EXPECT_EQ(3, p.get_y());

        Point p2(2, 3);
        p2+=p;
        EXPECT_EQ(4, p2.get_x());
        EXPECT_EQ(6, p2.get_y());

        Point p3 = p2 - p;

        EXPECT_EQ(2, p3.get_x());
        EXPECT_EQ(3, p3.get_y());
        EXPECT_TRUE(p == p3);

        Point p4(4, 6);
        Point p5(4, 6);
        EXPECT_FALSE(p4 != p5);

    } ENDM

    TEST(Test6, Snake) {

        snake.set_size(5);
        EXPECT_EQ(5, snake.get_size());

        snake.set_score(10);
        EXPECT_EQ(10, snake.get_score());

        snake.set_speed(0.2);
        EXPECT_EQ(0.2, snake.get_speed());

        snake.get_head().set_x(5);
        snake.get_head().set_y(5);
        EXPECT_EQ(5, snake.get_head().get_x());
        EXPECT_EQ(5, snake.get_head().get_y());

        snake.get_body().add(Point(6, 6));
        snake.get_body().add(Point(7, 7));
        EXPECT_EQ(2, snake.get_body().size());

        Node<Point>* head = snake.get_body().get_head();
        EXPECT_EQ(7, head->data.get_x());
        EXPECT_EQ(7, head->data.get_y());

        head = head->next;
        EXPECT_EQ(6, head->data.get_x());
        EXPECT_EQ(6, head->data.get_y());

        snake.set_direction(KEY_RIGHT);
        EXPECT_EQ(-23, snake.get_direction());

        snake.crash(field);
        fruit = new Green();
        fruit->set_pos(6, 8);
        field.get_wall().set_x(5);
        field.get_wall().set_y(5);
        EXPECT_TRUE(snake.crash(field));
        EXPECT_FALSE(snake.eat(fruit->get_pos()));
        delete fruit;

        Point p = snake.get_tail();
        EXPECT_EQ(6, p.get_x());
        EXPECT_EQ(6, p.get_y());


        snake.get_body().clear();
        snake.print_score(50);
        econio_gotoxy(0, 25);

    } ENDM
}

Game::~Game(){
    snake.get_body().clear();
}
