#ifndef POINT_H
#define POINT_H

/**
 * @brief Két dimenziós pontot reprezentáló osztály.
 *
 * A pont x (vízszintes) és y (függőleges) koordinátákat tárol, valamint alapvető műveleteket biztosít.
 */

class Point{
protected:
    int x, y; /**< A pont vízszintes (x) és függőleges (y) koordinátája. */
public:

    /**
     * @brief Alapértelmezett konstruktor, (0,0) koordinátával.
     */

    Point() : x(0), y(0){}

    /**
     * @brief Konstruktor, amely beállítja a pont koordinátáit.
     * @param horizontal A vízszintes (x) koordináta.
     * @param vertical A függőleges (y) koordináta.
     */

    Point(int horizontal, int vertical) : x(horizontal), y(vertical){}

    /**
     * @brief Visszaadja a vízszintes (x) koordinátát.
     * @return Az x koordináta értéke.
     */

    int get_x() const {return x;}

    /**
     * @brief Visszaadja a függőleges (y) koordinátát.
     * @return Az y koordináta értéke.
     */

    int get_y() const {return y;}

    /**
     * @brief Beállítja a vízszintes (x) koordinátát.
     * @param horizontal Az új vízszintes koordináta értéke.
     */

    void set_x (int horizontal){x=horizontal;}

    /**
     * @brief Beállítja a függőleges (y) koordinátát.
     * @param vertical Az új függőleges koordináta értéke.
     */

    void set_y(int vertical){y=vertical;}

    /**
     * @brief Összead két pontot.
     * @param pont A hozzáadandó pont.
     * @return Az összeadás eredménye (új Point).
     */

    Point& operator+=(const Point& pont) {
        x+=pont.x;
        y+=pont.y;
        return *this;
    }

    /**
     * @brief Kivon két pontot.
     * @param pont A kivonandó pont.
     * @return Az eredmény (új Point).
     */

    Point operator-(Point& pont) const { return Point(x-pont.x, y-pont.y); }

    /**
     * @brief Ellenőrzi, hogy a két pont egyenlő-e.
     * @param pont A másik pont.
     * @return Igaz, ha a két pont egyenlő, hamis egyébként.
     */

    bool operator==(const Point& pont) const { return (x==pont.x && y==pont.y); }

    /**
     * @brief Ellenőrzi, hogy a két pont nem egyenlő-e.
     * @param pont A másik pont.
     * @return Igaz, ha a két pont nem egyenlő, hamis egyébként.
     */

    bool operator!=(Point& pont) const { return !(*this==pont); }

    /**
     * @brief Destruktor, alapértelmezett.
     */
    ~Point() = default;
};

#endif //POINT_H
