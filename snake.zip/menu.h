#ifndef MENU_H
#define MENU_H

class menu {
public:
    void main_menu();
    void user_manual();
    void new_game();
    void load();
    void quit();
};

#endif //MENU_H
