#ifndef PURPLE_H
#define PURPLE_H

#include "fruit.h"
#include "snake.h"
#include "field.h"

/**
 * @brief A lila gyümölcsöt reprezentáló osztály, amely a Fruit osztályból származik.
 */

class Purple : public Fruit {
public:

    /**
    * @brief A lila gyümölcs hatása a kígyóra: felgyorsítja a kígyót.
    * @param kigyo A kígyó objektum referenciája.
    * @param szelesseg A pálya szélessége.
    * @param magassag A pálya magassága.
    */

    void affect(Snake& kigyo, int szelesseg, int magassag) override;

};

#endif //PURPLE_H
