#ifndef SNAKE_H
#define SNAKE_H

#include "point.h"
#include "field.h"
#include "list.h"
#include "fruit.h"

class White;

class Game;

/**
 * @brief A kígyót reprezentáló osztály.
 *
 * Kezeli a kígyó testét, fejét, méretét, irányát, pontszámát és sebességét, valamint a mozgással, ütközéssel, evéssel kapcsolatos műveleteket.
 */

class Snake{

protected:

    List<Point> body;              /**< A kígyó testét alkotó pontok listája. */
    Point head;                    /**< A kígyó fejének pozíciója. */
    int size = 5;                  /**< A kígyó aktuális mérete. */
    int direction_of_movement;     /**< A kígyó mozgási iránya. */
    int score = 0;                 /**< A játékos pontszáma. */
    double speed = 0.145;          /**< A kígyó mozgási sebessége. */

public:

    /**
     * @brief Alapértelmezett konstruktor.
     */

    Snake() {}

    /**
     * @brief Paraméteres konstruktor.
     * @param body_ A kígyó testét alkotó pontok listája.
     * @param fej A kígyó fejének pozíciója.
     * @param size_of_snake A kígyó mérete.
     * @param speed_of_snake A kígyó sebessége.
     */

    Snake(List<Point>& body_, Point fej, int size_of_snake, double speed_of_snake) :body(body_), head(fej), size(size_of_snake), speed(speed_of_snake){}

    /**
     * @brief Visszaadja a kígyó méretét.
     * @return A kígyó mérete.
     */

    int& get_size(){ return size; }

    /**
     * @brief Beállítja a kígyó méretét.
     * @param size_of_snake A kígyó új mérete.
     */

    void set_size(int size_of_snake){ size=size_of_snake; }

    /**
     * @brief Visszaadja a kígyó pontszámát.
     * @return A kígyó pontszáma.
     */

    int get_score() const { return score; }

    /**
     * @brief Beállítja a kígyó pontszámát.
     * @param score_data A kígyó új pontszáma.
     */

    void set_score(int score_data){ score=score_data; }

    /**
     * @brief Visszaadja a kígyó sebességét.
     * @return A kígyó sebessége.
     */

    double get_speed() const { return speed; }

    /**
     * @brief Beállítja a kígyó sebességét.
     * @param speed_of_snake A kígyó új sebessége.
     */

    void set_speed(double speed_of_snake){ speed=speed_of_snake; }

    /**
     * @brief Visszaadja a kígyó fejének pozícióját.
     * @return A kígyó fejének pozíciója (Point).
     */

    Point& get_head(){ return head; }

    /**
     * @brief Visszaadja a kígyó fejének pozícióját.
     * @return A kígyó fejének pozíciója (const Point).
     */

    const Point& get_head() const { return head; }

    /**
     * @brief Visszaadja a kígyó testét.
     * @return A kígyó testét alkotó pontok listája.
     */

    List<Point>& get_body(){ return body; }

    /**
     * @brief Visszaadja a kígyó testét.
     * @return A kígyó testét alkotó pontok listája (const).
     */

    const List<Point>& get_body() const { return body; }

    /**
     * @brief Visszaadja a kígyó mozgási irányát.
     * @return A kígyó mozgási iránya.
     */

    int get_direction(){ return direction_of_movement; }

    /**
     * @brief Beállítja a kígyó mozgási irányát.
     * @param direction_of_movement_data Az új mozgási irány.
     */

    void set_direction(int direction_of_movement_data){ direction_of_movement=direction_of_movement_data; }

    /**
     * @brief A kígyó mozgását, ütközését, gyümölcsevést és kirajzolását vezérlő fő ciklus.
     * @param field_data A pálya adatai.
     * @param fruit_data A gyümölcsre mutató pointer.
     */

    void move(Field& field_data, Fruit*& fruit_data);

    /**
     * @brief A kígyó irányának beállítása.
     * @return A kiválasztott irány (fel, le, balra, jobbra).
     */

    int direction();

    /**
     * @brief Ellenőrzi, hogy a kígyó ütközött-e falnak vagy saját magának.
     * @param field_data A pálya adatai.
     * @return Igaz, ha ütközés történt.
     */

    bool crash(Field& field_data);

    /**
     * @brief Növeli a kígyó méretét.
     * @param calories A növelés mértéke.
     */

    void size_inc(int calories);

    /**
     * @brief A kígyó teleportálása a pálya egy másik negyedébe.
     * @param szelesseg A pálya szélessége.
     * @param magassag A pálya magassága.
     * @param fruit_position A gyümölcs pozíciója.
     */

    void teleport(int szelesseg, int magassag, Point& fruit_position);

    /**
     * @brief A kígyó sebességének növelése.
     */

    void speed_up();

    /**
     * @brief Ellenőrzi, hogy a kígyó megeszi-e a gyümölcsöt.
     * @param position A gyümölcs pozíciója.
     * @return Igaz, ha a kígyó megeszi a gyümölcsöt.
     */

    bool eat(const Point& position);

    /**
     * @brief A kígyó fejének és testének kirajzolása a pályára.
     * @param x Az x koordináta.
     * @param y Az y koordináta.
     * @param body_type 0: fej, 1: test, -1: törlés.
     */

    void print(int x, int y, int body_type);

    /**
     * @brief A kígyó pontszámának kiírása a képernyő tetejére.
     * @param x Az x koordináta.
     */

    void print_score(int x) const;

    /**
     * @brief A kígyó farok pozíciójának visszaadása.
     * @return A kígyó farok pozíciója (Point).
     */

    Point get_tail();

 /**
  * @brief Destruktor, felszabadítja a kígyó testét.
  */

    ~Snake();
};
#endif //SNAKE_H
