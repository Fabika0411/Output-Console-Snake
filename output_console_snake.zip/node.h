#ifndef CONTAINER_H
#define CONTAINER_H

/**
 * @brief Sablon alapú láncolt lista csomópont struktúra.
 *
 * Egy láncolt lista egy elemét reprezentálja, amely tartalmazza az adatot és a következő elemre mutató pointert.
 * @tparam T A csomópontban tárolt adat típusa.
 */

template <typename T>
struct Node{
    T data;           /**< A csomópontban tárolt adat. */
    Node* next;       /**< A következő csomópontra mutató pointer. */

    /**
     * @brief Alapértelmezett konstruktor, üres adattal és nullptr következővel.
     */

    Node() : data(), next(nullptr) {}

    /**
     * @brief Konstruktor, amely beállítja az adatot és a következő pointert.
     * @param d Az adat.
     * @param n A következő csomópontra mutató pointer (alapértelmezett: nullptr).
     */

    explicit Node(T d, Node* n = nullptr) : data(d), next(n) {}

    /**
     * @brief Egyenlőség értékadó operátor (nem konstans referenciára).
     * @param n A másik csomópontra mutató pointer.
     * @return Referencia az aktuális csomópontra.
     */

    Node& operator=(Node& n); //egyenlőség operátor

    /**
     * @brief Egyenlőség értékadó operátor (konstans referenciára).
     * @param n A másik csomópont konstans referenciája.
     * @return Referencia az aktuális csomópontra.
     */

    Node& operator=(const Node& n);

    /**
    * @brief Nem egyenlő operátor.
    * @param n A másik csomópontra mutató pointer.
    * @return Referencia az aktuális csomópontra.
    */

    Node& operator!=(Node* n);
};

/// --- Metódusok implementációja ---

template <typename T>
Node<T>& Node<T>::operator=(Node<T>& n) {
    if(n==nullptr) {
        throw;
    }
    if(this!=n) {
        this->data = n.data;
        this->next = n.next;
        return *this;
    }
    return *this;
}
template <typename T>
Node<T>& Node<T>::operator=(const Node& n) {
    if (this != &n) {
        data = n.data;
        next = n.next;
    }
    return *this;
}
template <typename T>
Node<T>& Node<T>::operator!=(Node* n) {
    return this->data != n->data;
}
#endif //CONTAINER_H
