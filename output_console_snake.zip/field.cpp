#include <iostream>
#include "field.h"
#include "point.h"
#include "econio.h"
#include "node.h"
#include "ctime"
#include "cstdlib"
#include "list.h"
#include "snake.h"
#include "fruit.h"
#include "white.h"
#include "memtrace.h"

using namespace std;

/**
 *
 * Véletlenszerűen generál egy falat a pályán, úgy hogy ne essen a gyümölcs pozíciójára.
 * @param fruit_data A jelenlegi gyümölcs objektumra mutató pointer.
 */

void Field::wall_generate(Fruit*& fruit_data) {
    srand(time(nullptr));
    bool valid = false;
    int x, y;
    int attempts = 0;
    while (!valid && attempts++ < 1000) {
        x = rand() % (width-1) + 1;
        y = rand() % (height-1) + 1;
        valid = true;
        if( x==fruit_data->get_pos().get_x() && y==fruit_data->get_pos().get_y()) {
            valid = false;
        }
        else {
            valid = true;
        }
    }
    econio_gotoxy(x, y);
    econio_textcolor(COL_BLUE);
    cout<<"|";
    econio_textcolor(COL_RESET);
    wall.set_x(x);
    wall.set_y(y);
}

/**
 *
 * Véletlenszerűen generál egy gyümölcsöt a pályán, úgy hogy ne essen a kígyóra vagy a falra.
 * @param snake_data A kígyó objektum referenciája.
 * @param fruit_data A generálandó gyümölcs objektumra mutató pointer.
 * @param random_number Meghatározza a gyümölcs típusát/színét.
 */

void Field::fruit_generate(Snake& snake_data, Fruit*& fruit_data, int random_number) {
    srand(time(nullptr));
    bool valid = false;
    int x, y;
    Node<Point>* current = snake_data.get_body().get_head();
    while (current->next != nullptr) {
        current = current->next;
        while (!valid) {
            x = rand() % (width-1) + 1;
            y = rand() % (height-1) + 1;
            if ((wall.get_x() == x || x == current->data.get_x() || x == snake_data.get_head().get_x()) && (wall.get_y() == y  || y == current->data.get_y() || y == snake_data.get_head().get_y())) {
                valid=false;
            }
            valid = true;
        }
    }
    econio_gotoxy(x, y);
    if ( random_number == 0 ) {
        econio_textcolor(COL_WHITE);
        fruit_data->set_type(0);
        cout<<"G";
    }else if ( random_number == 1 ) {
        econio_textcolor(COL_GREEN);
        fruit_data->set_type(1);
        cout<<"G";
    }else if ( random_number == 2 ) {
        econio_textcolor(COL_MAGENTA);
        fruit_data->set_type(2);
        cout<<"G";
    }
    econio_textcolor(COL_RESET);
    fruit_data->set_pos(x, y);
}

/**
 *
 * A kígyót a pálya közepére helyezi és inicializálja a testét.
 * @param kigyo A kígyó objektum referenciája.
 */

void Field::snake_generate(Snake& kigyo) const{
    econio_gotoxy(width/2, height/2);
    int x = width/2;
    int y = height/2;
    kigyo.get_head().set_x(x);
    kigyo.get_head().set_y(y);
    econio_textcolor(COL_RED);
    cout<<">";
    econio_textcolor(COL_RESET);
    for(int i=0; i<kigyo.get_size(); i++) {
        kigyo.get_body().add(kigyo.get_head());
    }
    /*if (kigyo.get_direction()!=0) {
        while (kigyo.get_body().get_head()) {
            kigyo.get_body().get_head()->data.set_x(x);
            kigyo.get_body().get_head()->data.set_y(y);
            int body_part_x=kigyo.get_body().get_head()->data.get_x();
            int body_part_y=kigyo.get_body().get_head()->data.get_y();
            econio_gotoxy(body_part_x, body_part_y);
            econio_textcolor(COL_RED);
            cout<<"0";
            econio_textcolor(COL_RESET);
            kigyo.get_body().set_head(kigyo.get_body().get_head()->next);
        }
    }*/

}

